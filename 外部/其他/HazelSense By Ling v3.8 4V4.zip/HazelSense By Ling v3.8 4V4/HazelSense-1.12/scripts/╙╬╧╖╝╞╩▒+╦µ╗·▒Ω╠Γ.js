﻿var scriptName = "Time";//Js名字
var scriptVersion = 1.0;//Js版本
var scriptAuthor = "Ling";//Js作者

var Random = Java.type('java.util.Random');
var Display = Java.type('org.lwjgl.opengl.Display')

var Debug = new Debug();
var client;

function Debug() {
	var HM,H,M,S;//新建变量
	var random = new Random();
    var a = random.nextInt(13); //随机数
	//var a = Random //新建变量
    this.getName = function() {
        return "[HazelSense]丨BY Ling~丨QQ 2192931893";
    };//功能名字

    this.getDescription = function() {
        return "AquaVit";
    };//热点注释

    this.getCategory = function() {
        return "Fun";
    };//功能位置
    this.onEnable = function() {
		HM = 0;//tick
		H = 0;//小时
		M = 0;//分钟
		S = 0;//秒
    }//打开事件
    this.onUpdate = function() {
		HM += 1;//tick+1
        if (HM == 20){//如果等于20tick则+1 20tick=1秒
			S = S + 1;
			HM = 0;
		}
        if (S == 60){
		    M = M + 1;
			S = 0;
		}
        if (M == 60){
            H = H + 1;
			M = 0;
		}			
		switch (a){
			case 1:
                Display.setTitle("[HazelSense]欢迎你使用HazelSense|Made By Ling"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 2:
                Display.setTitle("[HazelSense]给岁月以文明，而不是给文明以岁月。"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 3:
                Display.setTitle("[HazelSense]上帝是个无耻的老赌徒，他抛弃了我们！"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;	
            case 4:
                Display.setTitle("[HazelSense]前进！前进！！不择手段地前进！！！"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;	
            case 5:
                Display.setTitle("[HazelSense]光锥之内就是命运。"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;	
            case 6:
                Display.setTitle("[HazelSense]死亡是唯一一座永远亮着的灯塔，不管你向哪里航行，最终都得转向它指引的方向。一切都会逝去，只有死神永生。"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;	
            case 7:
                Display.setTitle("[HazelSense]博物馆是给人看的，墓碑是给自己建的。"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;	
            case 8:
                Display.setTitle("[HazelSense]记忆是一条早已干涸的河流，只在毫无生气的河床中剩下零落的砾石。"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;	
            case 9:
                Display.setTitle("[HazelSense]Men always remember love because of romance only."+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;	
            case 10:
                Display.setTitle("[HazelSense]失去人性，失去很多；失去兽性，失去一切。"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;	
            case 11:
                Display.setTitle("[HazelSense]如果大山不会走向穆罕穆德，穆罕穆德可以走向大山。"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;	
            case 12:
                Display.setTitle("[HazelSense]不要返航，这里不是家！"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;					
            default:
                Display.setTitle('[HazelSense]你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
        }
	}//打开中事件
    this.onDisable = function () {	
	}//关闭事件
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(Debug);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}