﻿var scriptName = "NoFucker";
var scriptVersion = 3.0;
var scriptAuthor = "AquaVit"; //Thanks For AsOne help!!!!!!!!!!!
script.import('lib/minecraftUtils.js');
script.import('lib/timingFunctions.js');
script.import('lib/glFunctions.js');
script.import('lib/systemFunctions.js'); 
var RenderUtils = Java.type('net.ccbluex.liquidbounce.utils.render.RenderUtils')
var S02PacketChat = Java.type('net.minecraft.network.play.server.S02PacketChat')
var FuckerModule = moduleManager.getModule("Fucker");
var NoFucker = new NoFucker();
var NoFuckerclient;

function NoFucker() {
	var BE = value.createBoolean("BedESP", false);
	var Red = value.createInteger("Red", 108, 0, 255);
	var Green = value.createInteger("Green", 255, 0, 255);
	var Blue = value.createInteger("Blue", 255, 0, 255);
	var Alpha = value.createInteger("Alpha", 255, 0, 255);
	var BES = value.createList("ESPSetting", ["Box", "2D",], "Box");
    var BlockIDList = [26]
    var Block = Java.type('net.minecraft.block.Block')
    var BlockPos = Java.type("net.minecraft.util.BlockPos")
    var BlockUtils = Java.type('net.ccbluex.liquidbounce.utils.block.BlockUtils')
	var Color = Java.type('java.awt.Color')
    var targetX
    var targetY
    var targetZ

    function getClosestBlock(posX, posY, posZ, blpList) {
        blpList.sort(function (a, b) {
            var distanceA = a.distanceSqToCenter(posX, posY, posZ)
            var distanceB = b.distanceSqToCenter(posX, posY, posZ)

            return distanceA - distanceB;
        })
        return blpList[0]
    }

    function updateCloestBlockPos() {
		var posX = mc.thePlayer.posX
        var posY = mc.thePlayer.posY
        var posZ = mc.thePlayer.posZ
        var targetBlockList = []
        var searchDistance = 20
        for (var SearchX = posX - searchDistance; SearchX < posX + searchDistance; SearchX++) {
            for (var SearchY = posY - searchDistance; SearchY < posY + searchDistance; SearchY++) {
                for (var SearchZ = posZ - searchDistance; SearchZ < posZ + searchDistance; SearchZ++) {
                    var blp = new BlockPos(SearchX, SearchY, SearchZ)
                    if (!mc.theWorld.isAirBlock(blp)) {
                        var BlockID = Block.getIdFromBlock(BlockUtils.getBlock(blp))
                        if (BlockIDList.indexOf(BlockID) != -1) {
                            targetBlockList.push(blp)
                        }
                    }
                }
            }
        }
        if (targetBlockList.length == 0) {
            targetX = null
            targetY = null
            targetZ = null
        }else{
            var cloestblp = getClosestBlock(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, targetBlockList)
            targetX = cloestblp.getX()
            targetY = cloestblp.getY()
            targetZ = cloestblp.getZ()
            chat.print("§b[XM Anre] " + "§c已经标记您的床 您的fucker不会挖你家的床")
        }
    }    
	this.getName = function() {
        return "NoFucker Bedwar";
    };

    this.getDescription = function() {
        return "AquaVit.";
    };

    this.getCategory = function() {
        return "Fun";
    };
    this.onEnable = function() {
        targetX = null
        targetY = null
        targetZ = null		
	}
	this.onPacket = function(event) {
	var packet = event.getPacket();
	if(packet instanceof S02PacketChat) {		
        if (packet.getChatComponent().getUnformattedText().contains("游戏开始 ...") || packet.getChatComponent().getUnformattedText().contains("开始战斗吧")) {
            targetX = null
            targetY = null
            targetZ = null
		    }
	    }
	};
    this.onUpdate = function() {
		if (targetX == null) {
			updateCloestBlockPos()
		} else {
			if (mc.thePlayer.posZ.toFixed(0).toString() > targetZ - 10 && mc.thePlayer.posZ.toFixed(0).toString() < targetZ + 10 && mc.thePlayer.posX.toFixed(0).toString() > targetX - 10 && mc.thePlayer.posX.toFixed(0).toString() < targetX + 10) {
			    FuckerModule.setState(false)
		    } else {
			    FuckerModule.setState(true)
	        }
	    }
	
	}
    this.onDisable = function () {}
	this.onRender3D = function(event) {
		if (BE.get() == true) {
		    switch(BES.get()) {
			    case "Box":	            
                RenderUtils.drawBlockBox(new BlockPos(targetX,targetY,targetZ),new Color(Red.get(),Green.get(),Blue.get(),Alpha.get()),true)				
				break;
			    case "2D":
				 RenderUtils.draw2D(new BlockPos(targetX,targetY,targetZ), new Color(Red.get(),Green.get(),Blue.get(),Alpha.get()).getRGB(), Color.BLACK.getRGB());							
				break;
			}
        }
		
	}	
	this.addValues = function(values) { 
		values.add(BE);
		values.add(Red);
		values.add(Green);
		values.add(Blue);
		values.add(Alpha);
		values.add(BES);
	}
}

function onLoad() {}

function onEnable() {
    NoFuckerClient = moduleManager.registerModule(NoFucker);
}

function onDisable() {
    moduleManager.unregisterModule(NoFuckerClient);
}