var scriptName = "AutoJump"; 
var scriptVersion = 1.1; 
var scriptAuthor = "soulplexis";

var autoJump = new AutoJump();
var autoJumpClient;

function AutoJump() {
	var TrueJump = value.createBoolean("RealJump", true);
	var Motion = value.createFloat("Motion", 0.42, 0.00, 1.00);
    this.getName = function() {
        return "AutoJump";
    };

    this.getDescription = function() {
        return "Jumps automatically.";
    };

    this.getCategory = function() {
        return "Movement";
    };
    this.onUpdate = function () {
		if(TrueJump.get() == true && mc.thePlayer.onGround) {
			mc.thePlayer.jump();
		} 
		if(TrueJump.get() == false && mc.thePlayer.onGround) {
			mc.thePlayer.motionY = Motion.get();
		}
		mc.gameSettings.keyBindJump.pressed = false;
	}
	this.onDisable = function() {
	}
	this.addValues = function(values) {
		values.add(TrueJump);
		values.add(Motion);
    }
}

function onLoad() {
};

function onEnable() {
    autoJumpClient = moduleManager.registerModule(autoJump);
};

function onDisable() {
    moduleManager.unregisterModule(autoJumpClient);
};