﻿var scriptName = "KillAuraHelper";
var scriptAuthor = "Deadstar";
var scriptVersion = 1.0;

var Scaffold = moduleManager.getModule("Scaffold");
var Killaura = moduleManager.getModule("Killaura")
var Velocity = moduleManager.getModule("Velocity")

function KaHelper() {
	
	var Mode = value.createList("Mode", ["HuaYuTing"], "HuaYuTing");
	
    this.getName = function() {
        return "KillAuraHelper";
    }
    this.getDescription = function() {
        return "Helper";
    }
    this.getCategory = function() {
        return "Fun"; 
    }
	this.getTag = function() {
        return Mode.get(); 
    }
    this.onEnable = function() {
   
    }
    this.onDisable = function() {
     
    }
    this.onUpdate = function() {
		if(Mode.get() == "HuaYuTing") {
			if(Scaffold.getState() == true && Killaura.getState()) {
				Killaura.setState(false);
			    if(Scaffold.getState() == true && Velocity.getState()) {
                    Velocity.setState(false);
                chat.print("[Deadstar]您打开了Scaffold已为您关闭KillAura!");
                }  
            }
		}
	}
    this.addValues = function(values) {
        values.add(Mode);
	}
}
var KaHelper = new KaHelper();
var KaHelperClient;

function onLoad() {}

function onEnable() {
    KaHelperClient = moduleManager.registerModule(KaHelper);
}

function onDisable() {
    moduleManager.unregisterModule(KaHelperClient);
}