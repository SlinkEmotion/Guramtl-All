var scriptName = "NiceVelocity";
var scriptAuthor = "FunkNight";
var scriptVersion = 1.0;

var exampleModule = new ExampleModule();
var exampleModuleClient;

var Timer = Java.type("net.ccbluex.liquidbounce.utils.timer.MSTimer");
var Delay = new Timer();

function ExampleModule() {
	var random = new Random();
	var target = null;
	var Mode = value.createList("Mode", ["Hurttime","MSTimer"], "Hurttime");
    this.getName = function() {
        return "HYTVelocity";
    }
    this.getDescription = function() {
        return "Velocity";
    }
    this.getCategory = function() {
        return "Combat"; 
    }
    this.getTag = function(){
        return "Ready";
    }

    this.onAttack = function(event) {
        target = event.getTargetEntity();
    }
	this.onEnable = function() {
		chat.print("HYTVelociti")
	}
    this.onUpdate = function() {
		if(mc.thePlayer.hurtTime > 0 || target != null) {
			switch(Mode.get()){
				case "Hurttime":
					if(mc.thePlayer.onGround){
						if(mc.thePlayer.hurtTime > 0 && mc.thePlayer.hurtTime <= 7){
							mc.thePlayer.motionX *= 0.9114514;
							mc.thePlayer.motionZ *= 0.9114514;
						}
						if(mc.thePlayer.hurtTime > 0 && mc.thePlayer.hurtTime <= 2){
							mc.thePlayer.motionX *= 0.656114514;
							mc.thePlayer.motionZ *= 0.656114514;
						}
					}else{
						if(mc.thePlayer.hurtTime > 0) {
							mc.thePlayer.motionX *= 0.8001421204;
							mc.thePlayer.motionZ *= 0.8001421204;
						}
					}
				break
				case "MSTimer":
					if(Delau.hasTimePassed(60)){
						mc.thePlayer.motionX *= 0.81;
						mc.thePlayer.motionZ *= 0.81;
						if(Delay.hasTimePassed(120)){
							mc.thePlayer.motionX *= 0.81;
							mc.thePlayer.motionZ *= 0.81;
						}
					}
				break
			}
		}
	}
	this.addValues = function(values) {
			values.add(Mode)
	}
}

function onLoad() {}

function onEnable() {
    exampleModuleClient = moduleManager.registerModule(exampleModule);
}

function onDisable() {
    moduleManager.unregisterModule(exampleModuleClient);
}