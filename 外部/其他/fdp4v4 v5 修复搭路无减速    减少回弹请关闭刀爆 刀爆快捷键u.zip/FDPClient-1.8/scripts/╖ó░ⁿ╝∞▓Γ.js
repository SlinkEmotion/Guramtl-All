﻿var scriptName = "发包检测"; 
var scriptVersion = 1.0; 
var scriptAuthor = "LikeZhiNai"; 

var PacketMore = new PacketMore();
var PacketMoreClient;
var colorIndex = 0;

function printMessage(message) {
    var availableColors = ["§a发包过多§b"];
    var color = availableColors[colorIndex];
    colorIndex += 1;
    if (colorIndex >= availableColors.length) {
        colorIndex = 0;
    }
    chat.print(color + message + "§r");
}
function PacketMore() {
	var ticks = 0;
	var packets = 0;
    this.getName = function() {
        return "NewPacket";
    };

    this.getDescription = function() {
        return "NewPacket";
    };

    this.getCategory = function() {
        return "Fun";
    };
	this.onEnable = function() {
	}

   this.onUpdate = function() {
	   ticks++;
	   if(ticks >= 20) {
		   ticks = 0;
		   packets = 0;
	   }
	   if(packets >=500) {
		   printMessage("  {Airns Config}当前发包频率 " + packets + "/s");
	   }
   }
    this.onPacket = function() {
		packets++;
		
   }
    this.onDisable = function() {
    }
}
function onLoad() {
};
function onEnable() {
    PacketMoreClient = moduleManager.registerModule(PacketMore);
};
function onDisable() {
    moduleManager.unregisterModule(PacketMoreClient);
};