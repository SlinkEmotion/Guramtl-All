var scriptName = "VulcanLegitFly"//魔改倒卖神一律死爹烂妈
var scriptVersion = 1.0
var scriptAuthor = "PacketJuzi"
var JuZiModule = new JuZiModule()
var JuZiModuleClient
var Fly = moduleManager.getModule('Fly')
var HighJump = moduleManager.getModule('HighJump')
var ticks = 0
function JuZiModule() {
    this.getName = function() {
        return "VulcanLegitFLy"
    }
    this.getDescription = function() {
        return "Vulcan2.6.2"
    }
    this.getCategory = function() {
        return "Fun"
    }
    this.onEnable = function() {
Fly.getValue('mode').set("Vulcan")
HighJump.getValue('mode').set("Vanilla")
HighJump.setState(true)
Chat.print("You Must Use FDPCNCLIENT To Let Is Module Work!!!")
mc.thePlayer.jump();

    }
    this.onDisable = function() { 
Fly.setState(false)
HighJump.setState(false)

ticks = 0
	
    }
    this.onUpdate = function() { 
ticks++
if(ticks == 25){
	Fly.setState(true)
}

}
	this.onPacket = function() { 
    }
}
function onLoad() {}
function onEnable() {
   JuZiModuleClient = moduleManager.registerModule(JuZiModule)
}
function onDisable() {
    moduleManager.unregisterModule(JuZiModuleClient)
}