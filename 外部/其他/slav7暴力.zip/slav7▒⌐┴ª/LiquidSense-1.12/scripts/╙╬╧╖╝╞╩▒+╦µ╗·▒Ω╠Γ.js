﻿var scriptName = "Time";//Js名字
var scriptVersion = 1.0;//Js版本
var scriptAuthor = "AquaVit";//Js作者

var Random = Java.type('java.util.Random');
var Display = Java.type('org.lwjgl.opengl.Display')

var Debug = new Debug();
var client;

function Debug() {
	var HM,H,M,S;//新建变量
	var random = new Random();
    var a = random.nextInt(13); //随机数
	//var a = Random //新建变量
    this.getName = function() {
        return "Title";
    };//功能名字

    this.getDescription = function() {
        return "AquaVit";
    };//热点注释

    this.getCategory = function() {
        return "Fun";
    };//功能位置
    this.onEnable = function() {
		HM = 0;//tick
		H = 0;//小时
		M = 0;//分钟
		S = 0;//秒
    }//打开事件
    this.onUpdate = function() {
		HM += 1;//tick+1
        if (HM == 20){//如果等于20tick则+1 20tick=1秒
			S = S + 1;
			HM = 0;
		}
        if (S == 60){
		    M = M + 1;
			S = 0;
		}
        if (M == 60){
            H = H + 1;
			M = 0;
		}			
		switch (a){
			case 1:
                Display.setTitle("SLA公益 4v4配置纯属免费 QQ群+914978343"+"你对一个人太好，别人觉得理所当然，变本加厉伤害你。以前，你太在乎别人了，以后不会了 |"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 2:
                Display.setTitle("SLA公益 4v4配置纯属免费 QQ群+914978343"+"真心给了别人，留下来的却是 寒心，何苦呢？该得罪的人，还是要得罪，别在乎面子。人家不给你面子，那就撕破面子 |"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 3:
                Display.setTitle("SLA公益 4v4配置纯属免费 QQ群+914978343"+"太在乎别人，是卑微了自己，是让自己成为一块任别人践踏的垫脚石。 |"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 4:
                Display.setTitle("SLA公益 4v4配置纯属免费 QQ群+914978343"+"人生几十年，要好好活着，别伪装成人不人，鬼不鬼。白天对着别人笑，夜里对着自己苦，你这是何苦呢？ |"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 5:
                Display.setTitle("SLA公益 4v4配置纯属免费 QQ群+914978343"+"开心就笑，痛苦就哭，忧愁就不作声，发怒就大吼，没什么，理解你的人，懂得你的喜怒哀乐，不理解你的人，低声下气解释也没有用。 |"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 6:
                Display.setTitle("SLA公益 4v4配置纯属免费 QQ群+914978343"+"亲爱的自己，一切都会过去的，别耿耿于怀了，别躲在藏着。该来的回来，该走的回走，躲得过初一，躲不过十五。 |"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 7:
                Display.setTitle("SLA公益 4v4配置纯属免费 QQ群+914978343"+"与其躲躲藏藏，不如直接面对。人生总有过不去的槛，也有绕不过的弯，顺其自然吧，心顺了，也就好了。 |"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 8:
                Display.setTitle("SLA公益 4v4配置纯属免费 QQ群+914978343"+"别为生活找不愉快，别因为任何人，为难自己。你烦恼，你闹心，你坐卧不安，最后伤害的是自己 |"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 9:
                Display.setTitle("SLA公益 4v4配置纯属免费 QQ群+914978343"+"健健康康最重要了，比你那些加班加点更重要，比赚钱更重要。从今往后，困了睡觉，饿了吃饭，累了休息。 |"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 10:
                Display.setTitle("SLA公益 4v4配置纯属免费 QQ群+914978343"+"以前总是傻乎乎的，为了顾全别人，迷失了自己。总以为傻乎乎也是爱，可是不知道，“狡猾”才是保护自己。 |"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 11:
                Display.setTitle("SLA公益 4v4配置纯属免费 QQ群+914978343"+"一个人，别真的傻，要懂得，厉害的人，“揣着明白装糊涂”。 |"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            case 12:
                Display.setTitle("SLA公益 4v4配置纯属免费 QQ群+914978343"+"你总是生气，你才是世上最傻的人。生气解决不了任何问题。只是让自己的情绪越来越糟糕。 |"+ ' 你已经游玩了: '+ H  +'时'  +M +'分'+S+'秒');
                break;
            default:
                
        }
	}//打开中事件
    this.onDisable = function () {	
	}//关闭事件
}

function onLoad() {}

function onEnable() {
    client = moduleManager.registerModule(Debug);
}

function onDisable() {
    moduleManager.unregisterModule(client);
}