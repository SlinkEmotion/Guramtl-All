﻿var scriptName = 'ScaffoldHelper'
var scriptAuthor = 'FunkNight'
var scriptVersion = 999.0

function ScaffoldHelper() {
	var RotationUtils = Java.type('net.ccbluex.liquidbounce.utils.RotationUtils')
	var Rotation = Java.type('net.ccbluex.liquidbounce.utils.Rotation')
	var Scaffold = moduleManager.getModule('Scaffold')
	function isMoving() {
        return mc.thePlayer.movementInput.moveForward || mc.thePlayer.movementInput.moveStrafe;
    }
	this.getName = function () {
		return 'ScaffoldHelper'
	}

	this.getDescription = function () {
		return 'ScaffoldAddon'
	}

    	this.getTag = function() {
   	     return "Hypixel";
 	}
	this.getCategory = function () {
		return 'Fun'
	}
	this.onUpdate = function () {
		if(Scaffold.getState()) {
			if(isMoving()){
				Scaffold.getValue('Rotations').set(false)
				DiffYaw = 0
				if(mc.thePlayer.movementInput.moveForward > 0) DiffYaw = 180
				if(mc.thePlayer.movementInput.moveForward < 0) DiffYaw = 0
				RotationUtils.setTargetRotation(new Rotation(mc.thePlayer.rotationYaw + DiffYaw, 85))
				
			}else{
				Scaffold.getValue('Rotations').set(true)
			}
		}
	}
}

var ScaffoldHelper = new ScaffoldHelper()
var ScaffoldHelperClient

function onEnable() {
	ScaffoldHelperClient = moduleManager.registerModule(ScaffoldHelper)
}

function onDisable() {
	moduleManager.unregisterModule(ScaffoldHelperClient)
}