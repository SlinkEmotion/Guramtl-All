var C0FPacketConfirmTransaction = Java.type('net.minecraft.network.play.client.C0FPacketConfirmTransaction'),
    C00PacketKeepAlive = Java.type('net.minecraft.network.play.client.C00PacketKeepAlive'),
    MSTimer = Java.type('net.ccbluex.liquidbounce.utils.timer.MSTimer'),
    C08PacketPlayerBlockPlacement = Java.type('net.minecraft.network.play.client.C08PacketPlayerBlockPlacement'),
    C03PacketPlayer = Java.type('net.minecraft.network.play.client.C03PacketPlayer'),
    C07PacketPlayerDigging = Java.type('net.minecraft.network.play.client.C07PacketPlayerDigging'),
    meme = 0,
    memeIDs = [],
    packetMeme = 0,
    msTimer = new MSTimer(),
    transactions = [],
    keepAlives = [];
var script = registerScript({
    name: 'Scaffold-Disabler',
    version: '0.0.0',
    authors: ['Liuli loli confirmed']
});
script.registerModule({
    name: 'Scaffold-Disabler',
    category: 'Fun',
    description: 'AdvancedAntiCat-Scaffold-Check-Disabler'

}, function(module) {
    module.on('packet', function(e) {
        var packet = e.getPacket();
        // if (packet instanceof C00PacketKeepAlive && packet != keepAlives[keepAlives.length - 1]) {
        //     keepAlives.push(packet);
        //     e.cancelEvent();
        // }
        // if (packet instanceof C0FPacketConfirmTransaction && packet != transactions[transactions.length - 1]) {
        //     transactions.push(packet);
        //     e.cancelEvent();
        // }

        if (packet instanceof C08PacketPlayerBlockPlacement) {

            mc.netHandler.addToSendQueue(C03PacketPlayer())
            mc.netHandler.addToSendQueue(C07PacketPlayerDigging())
            mc.netHandler.addToSendQueue(C0FPacketConfirmTransaction(0, 0, false))

        }
    });
    module.on('update', function() {

    });
    module.on('enable', function() {
        meme = 0;
        memeIDs = [];
    });
});